import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import QRCode from 'react-native-qrcode-svg';
import { useAuthStore } from '../../src/store/useAuthStore';
import { Button } from '../../src/components/Button';
import * as Location from 'expo-location';
import { Ionicons } from '@expo/vector-icons';

export default function CheckInScreen() {
    const { academyId, academyName } = useLocalSearchParams();
    const { user, session } = useAuthStore();
    const [loading, setLoading] = useState(false);
    const [checkinSuccess, setCheckinSuccess] = useState(false);
    const [checkinData, setCheckinData] = useState<any>(null);
    const router = useRouter();

    // Gym Panel API URL - Replace with your actual local IP or deployed URL
    // For Android Emulator use 10.0.2.2, for iOS Simulator use localhost
    // Ensure this matches where gym-panel is running
    const API_URL = 'http://localhost:3000/api/checkins';

    const handleCheckIn = async () => {
        if (!user || !academyId) return;
        setLoading(true);

        try {
            // 1. Get Location
            let { status } = await Location.requestForegroundPermissionsAsync();
            if (status !== 'granted') {
                Alert.alert('Permissão negada', 'Precisamos da sua localização para validar o check-in.');
                setLoading(false);
                return;
            }

            let location = await Location.getCurrentPositionAsync({});
            const { latitude, longitude } = location.coords;

            // 2. Call Backend API
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${session?.access_token}`, // Send Supabase token
                },
                body: JSON.stringify({
                    academy_id: academyId,
                    latitude,
                    longitude,
                }),
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Falha ao realizar check-in');
            }

            setCheckinSuccess(true);
            setCheckinData(data.checkin);

        } catch (error: any) {
            Alert.alert('Erro no Check-in', error.message);
        } finally {
            setLoading(false);
        }
    };

    if (checkinSuccess) {
        return (
            <View style={styles.container}>
                <View style={styles.successCard}>
                    <Ionicons name="checkmark-circle" size={80} color="#22c55e" />
                    <Text style={styles.successTitle}>Check-in Realizado!</Text>
                    <Text style={styles.successSubtitle}>{academyName}</Text>
                    <Text style={styles.timestamp}>
                        {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </Text>

                    <View style={styles.qrContainer}>
                        <QRCode value={JSON.stringify({ checkinId: checkinData?.id })} size={200} />
                        <Text style={styles.qrLabel}>Comprovante de Acesso</Text>
                    </View>

                    <Button
                        title="Voltar ao Início"
                        onPress={() => router.replace('/(tabs)/home')}
                        style={{ marginTop: 24, width: '100%' }}
                    />
                </View>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Check-in</Text>
            <Text style={styles.subtitle}>{academyName}</Text>

            <View style={styles.instructionContainer}>
                <Ionicons name="location-outline" size={48} color="#ffffff" />
                <Text style={styles.instruction}>
                    Para realizar o check-in, você precisa estar próximo à academia (até 300m).
                </Text>
            </View>

            <Button
                title="Fazer Check-in Agora"
                onPress={handleCheckIn}
                loading={loading}
                style={styles.checkinButton}
                textStyle={{ fontSize: 18, fontWeight: 'bold' }}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#2563eb',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 24,
    },
    title: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#ffffff',
        marginBottom: 8,
    },
    subtitle: {
        fontSize: 20,
        color: 'rgba(255,255,255,0.8)',
        marginBottom: 48,
    },
    instructionContainer: {
        alignItems: 'center',
        marginBottom: 48,
        paddingHorizontal: 24,
    },
    instruction: {
        color: '#ffffff',
        marginTop: 16,
        fontSize: 16,
        textAlign: 'center',
        opacity: 0.9,
        lineHeight: 24,
    },
    checkinButton: {
        width: '100%',
        height: 56,
        backgroundColor: '#ffffff',
    },
    successCard: {
        backgroundColor: '#ffffff',
        borderRadius: 24,
        padding: 32,
        alignItems: 'center',
        width: '100%',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.2,
        shadowRadius: 20,
        elevation: 10,
    },
    successTitle: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#111827',
        marginTop: 16,
    },
    successSubtitle: {
        fontSize: 18,
        color: '#6b7280',
        marginTop: 4,
    },
    timestamp: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#2563eb',
        marginTop: 16,
        marginBottom: 24,
    },
    qrContainer: {
        alignItems: 'center',
        padding: 16,
        backgroundColor: '#f3f4f6',
        borderRadius: 16,
        width: '100%',
    },
    qrLabel: {
        marginTop: 12,
        color: '#6b7280',
        fontSize: 14,
    }
});
