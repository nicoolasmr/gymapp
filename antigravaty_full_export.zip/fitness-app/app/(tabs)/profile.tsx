import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, RefreshControl, Alert, TextInput, Share, Modal } from 'react-native';
import { useAuthStore } from '../../src/store/useAuthStore';
import { userService } from '../../src/services/userService';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

export default function ProfileScreen() {
    const { user, signOut } = useAuthStore();
    const router = useRouter();
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    const [profile, setProfile] = useState<any>(null);
    const [membership, setMembership] = useState<any>(null);
    const [stats, setStats] = useState({ totalCheckins: 0, streak: 0 });
    const [history, setHistory] = useState<any[]>([]);
    const [familyDetails, setFamilyDetails] = useState<any>(null);
    const [isEditing, setIsEditing] = useState(false);
    const [newName, setNewName] = useState('');

    const fetchData = async () => {
        if (!user) return;
        try {
            const [userProfile, userMembership, userStats, userHistory, userFamily] = await Promise.all([
                userService.getUserProfile(user.id),
                userService.getMembership(user.id),
                userService.getStats(user.id),
                userService.getCheckinHistory(user.id),
                userService.getFamilyDetails(user.id)
            ]);

            setProfile(userProfile);
            setNewName(userProfile?.full_name || '');
            setMembership(userMembership);
            setStats(userStats);
            setHistory(userHistory || []);
            setFamilyDetails(userFamily);
        } catch (error: any) {
            console.error(error);
            Alert.alert('Erro', 'Não foi possível carregar os dados do perfil.');
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, [user]);

    const onRefresh = () => {
        setRefreshing(true);
        fetchData();
    };

    const handleUpdateProfile = async () => {
        if (!user) return;
        try {
            await userService.updateUserProfile(user.id, { full_name: newName });
            setProfile({ ...profile, full_name: newName });
            setIsEditing(false);
            Alert.alert('Sucesso', 'Perfil atualizado!');
        } catch (error) {
            Alert.alert('Erro', 'Falha ao atualizar perfil.');
        }
    };

    const handleInviteMember = async () => {
        if (!user) return;
        try {
            const token = await userService.createFamilyInvite(user.id);
            const inviteLink = `fitnessapp://invite?token=${token}`;

            await Share.share({
                message: `Venha treinar comigo no Fitness App! Aceite meu convite para o Plano Família: ${inviteLink}`,
                url: inviteLink, // iOS only
            });

            // Refresh data to show pending invite if we were to show it
            fetchData();
        } catch (error: any) {
            Alert.alert('Erro', error.message || 'Não foi possível gerar o convite.');
        }
    };

    const handleRemoveMember = async (memberId: string) => {
        if (!user) return;
        Alert.alert(
            'Remover Membro',
            'Tem certeza que deseja remover este membro do plano?',
            [
                { text: 'Cancelar', style: 'cancel' },
                {
                    text: 'Remover',
                    style: 'destructive',
                    onPress: async () => {
                        try {
                            await userService.removeFamilyMember(user.id, memberId);
                            Alert.alert('Sucesso', 'Membro removido.');
                            fetchData();
                        } catch (error: any) {
                            Alert.alert('Erro', error.message || 'Falha ao remover membro.');
                        }
                    }
                }
            ]
        );
    };

    const handleSignOut = async () => {
        await signOut();
        router.replace('/(auth)/login');
    };

    const getBadge = (count: number) => {
        if (count >= 30) return { icon: 'trophy', color: '#fbbf24', label: 'Viciado' }; // Gold
        if (count >= 15) return { icon: 'medal', color: '#9ca3af', label: 'Comprometido' }; // Silver
        if (count >= 5) return { icon: 'ribbon', color: '#b45309', label: 'Iniciante' }; // Bronze
        return null;
    };

    const badge = getBadge(stats.totalCheckins);

    return (
        <ScrollView
            style={styles.container}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        >
            {/* Header */}
            <View style={styles.header}>
                <View style={styles.avatarContainer}>
                    <Image
                        source={{ uri: profile?.avatar_url || 'https://via.placeholder.com/100' }}
                        style={styles.avatar}
                    />
                    <TouchableOpacity style={styles.editAvatarButton}>
                        <Ionicons name="camera" size={20} color="#fff" />
                    </TouchableOpacity>
                </View>

                {isEditing ? (
                    <View style={styles.editNameContainer}>
                        <TextInput
                            style={styles.nameInput}
                            value={newName}
                            onChangeText={setNewName}
                        />
                        <TouchableOpacity onPress={handleUpdateProfile}>
                            <Ionicons name="checkmark-circle" size={28} color="#2563eb" />
                        </TouchableOpacity>
                    </View>
                ) : (
                    <View style={styles.nameContainer}>
                        <Text style={styles.name}>{profile?.full_name || 'Usuário'}</Text>
                        <TouchableOpacity onPress={() => setIsEditing(true)}>
                            <Ionicons name="pencil" size={16} color="#6b7280" />
                        </TouchableOpacity>
                    </View>
                )}
                <Text style={styles.email}>{user?.email}</Text>
            </View>

            {/* Stats Grid */}
            <View style={styles.statsGrid}>
                <View style={styles.statCard}>
                    <Text style={styles.statValue}>{stats.totalCheckins}</Text>
                    <Text style={styles.statLabel}>Check-ins</Text>
                </View>
                <View style={styles.statCard}>
                    <Text style={styles.statValue}>{stats.streak} dias</Text>
                    <Text style={styles.statLabel}>Sequência</Text>
                </View>
            </View>

            {/* Invite & Earn Banner */}
            <TouchableOpacity
                style={styles.inviteBanner}
                onPress={() => router.push('/profile/referrals')}
            >
                <View style={styles.inviteContent}>
                    <Ionicons name="gift" size={24} color="#fff" />
                    <View style={styles.inviteTextContainer}>
                        <Text style={styles.inviteTitle}>Indique e Ganhe 10% OFF</Text>
                        <Text style={styles.inviteSubtitle}>Convide amigos e ganhe descontos</Text>
                    </View>
                </View>
                <Ionicons name="chevron-forward" size={24} color="#fff" />
            </TouchableOpacity>

            {/* Plan Info */}
            < View style={styles.section} >
                <Text style={styles.sectionTitle}>Meu Plano</Text>
                <View style={styles.card}>
                    {membership ? (
                        <>
                            <View style={styles.planHeader}>
                                <Text style={styles.planName}>
                                    {membership.plan_id === 1 ? 'Plano Solo' : 'Plano Família'}
                                </Text>
                                <View style={[
                                    styles.statusBadge,
                                    { backgroundColor: membership.status === 'active' ? '#dcfce7' : '#fee2e2' }
                                ]}>
                                    <Text style={[
                                        styles.statusText,
                                        { color: membership.status === 'active' ? '#166534' : '#991b1b' }
                                    ]}>
                                        {membership.status === 'active' ? 'ATIVO' : 'INATIVO'}
                                    </Text>
                                </View>
                            </View>
                            <Text style={styles.planDate}>
                                Renovação: {new Date(membership.renewal_date || membership.start_date).toLocaleDateString()}
                            </Text>

                            {/* Family Members List (Only for Family Plan) */}
                            {membership.plan_id === 2 && familyDetails?.has_family && (
                                <View style={{ marginTop: 16, borderTopWidth: 1, borderTopColor: '#f3f4f6', paddingTop: 16 }}>
                                    <Text style={{ fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8 }}>
                                        Membros da Família ({familyDetails.members.length}/4)
                                    </Text>
                                    {familyDetails.members.map((member: any) => (
                                        <View key={member.id} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8, justifyContent: 'space-between' }}>
                                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                                <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: '#bfdbfe', alignItems: 'center', justifyContent: 'center', marginRight: 8 }}>
                                                    <Text style={{ color: '#1e40af', fontWeight: 'bold' }}>
                                                        {member.full_name?.charAt(0) || 'U'}
                                                    </Text>
                                                </View>
                                                <View>
                                                    <Text style={{ fontSize: 14, color: '#1f2937', fontWeight: '500' }}>
                                                        {member.full_name || 'Usuário'} {member.role === 'owner' && '(Titular)'}
                                                    </Text>
                                                    <Text style={{ fontSize: 12, color: '#6b7280' }}>{member.email}</Text>
                                                </View>
                                            </View>
                                            {familyDetails.is_owner && member.role !== 'owner' && (
                                                <TouchableOpacity onPress={() => handleRemoveMember(member.id)}>
                                                    <Ionicons name="trash-outline" size={20} color="#ef4444" />
                                                </TouchableOpacity>
                                            )}
                                        </View>
                                    ))}

                                    {/* Pending Invites */}
                                    {familyDetails.invites && familyDetails.invites.map((invite: any) => (
                                        <View key={invite.id} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8, justifyContent: 'space-between', opacity: 0.7 }}>
                                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                                <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: '#e5e7eb', alignItems: 'center', justifyContent: 'center', marginRight: 8 }}>
                                                    <Ionicons name="time-outline" size={16} color="#6b7280" />
                                                </View>
                                                <View>
                                                    <Text style={{ fontSize: 14, color: '#1f2937', fontWeight: '500', fontStyle: 'italic' }}>
                                                        Convite Pendente
                                                    </Text>
                                                    <Text style={{ fontSize: 12, color: '#6b7280' }}>Expira em {new Date(invite.expires_at).toLocaleDateString()}</Text>
                                                </View>
                                            </View>
                                        </View>
                                    ))}

                                    {familyDetails.is_owner && (familyDetails.members.length + (familyDetails.invites?.length || 0)) < 4 && (
                                        <TouchableOpacity style={{ marginTop: 8 }} onPress={handleInviteMember}>
                                            <Text style={{ color: '#2563eb', fontSize: 14, fontWeight: '500' }}>
                                                + Adicionar Membro
                                            </Text>
                                        </TouchableOpacity>
                                    )}
                                </View>
                            )}
                        </>
                    ) : (
                        <View style={styles.noPlan}>
                            <Text style={styles.noPlanText}>Você ainda não tem um plano ativo.</Text>
                            <TouchableOpacity
                                style={styles.subscribeButton}
                                onPress={() => router.push('/modal/subscribe')}
                            >
                                <Text style={styles.subscribeButtonText}>Assinar Agora</Text>
                            </TouchableOpacity>
                        </View>
                    )}
                </View>
            </View >

            {/* History */}
            < View style={styles.section} >
                <Text style={styles.sectionTitle}>Histórico de Treinos</Text>
                {
                    history.length > 0 ? (
                        history.map((checkin) => (
                            <View key={checkin.id} style={styles.historyItem}>
                                <View style={styles.historyIcon}>
                                    <Ionicons name="barbell" size={20} color="#2563eb" />
                                </View>
                                <View style={styles.historyInfo}>
                                    <Text style={styles.historyAcademy}>{checkin.academies?.name}</Text>
                                    <Text style={styles.historyDate}>
                                        {new Date(checkin.created_at).toLocaleDateString()} às {new Date(checkin.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                    </Text>
                                </View>
                            </View>
                        ))
                    ) : (
                        <Text style={styles.emptyText}>Nenhum treino registrado ainda.</Text>
                    )
                }
            </View >

            <TouchableOpacity style={styles.logoutButton} onPress={handleSignOut}>
                <Text style={styles.logoutText}>Sair da Conta</Text>
            </TouchableOpacity>

            <View style={{ height: 40 }} />
        </ScrollView >
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f9fafb',
    },
    header: {
        alignItems: 'center',
        padding: 24,
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderBottomColor: '#e5e7eb',
    },
    avatarContainer: {
        position: 'relative',
        marginBottom: 16,
    },
    avatar: {
        width: 100,
        height: 100,
        borderRadius: 50,
        backgroundColor: '#e5e7eb',
    },
    editAvatarButton: {
        position: 'absolute',
        bottom: 0,
        right: 0,
        backgroundColor: '#2563eb',
        padding: 8,
        borderRadius: 20,
        borderWidth: 2,
        borderColor: '#fff',
    },
    nameContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        marginBottom: 4,
    },
    editNameContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        marginBottom: 4,
    },
    nameInput: {
        fontSize: 20,
        fontWeight: 'bold',
        borderBottomWidth: 1,
        borderBottomColor: '#2563eb',
        padding: 0,
        minWidth: 150,
        textAlign: 'center',
    },
    name: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#111827',
    },
    email: {
        fontSize: 16,
        color: '#6b7280',
    },
    statsContainer: {
        flexDirection: 'row',
        backgroundColor: '#fff',
        margin: 16,
        padding: 16,
        borderRadius: 16,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
        elevation: 2,
        justifyContent: 'space-around',
        alignItems: 'center',
    },
    statItem: {
        alignItems: 'center',
    },
    statValue: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#111827',
        marginBottom: 4,
    },
    statLabel: {
        fontSize: 12,
        color: '#6b7280',
        textTransform: 'uppercase',
    },
    divider: {
        width: 1,
        height: 40,
        backgroundColor: '#e5e7eb',
    },
    section: {
        padding: 16,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#111827',
        marginBottom: 12,
    },
    card: {
        backgroundColor: '#fff',
        padding: 16,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#e5e7eb',
    },
    planHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 8,
    },
    planName: {
        fontSize: 18,
        fontWeight: '600',
        color: '#111827',
    },
    statusBadge: {
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 12,
    },
    statusText: {
        fontSize: 12,
        fontWeight: 'bold',
    },
    planDate: {
        fontSize: 14,
        color: '#6b7280',
    },
    noPlan: {
        alignItems: 'center',
        padding: 8,
    },
    noPlanText: {
        color: '#6b7280',
        marginBottom: 12,
    },
    subscribeButton: {
        backgroundColor: '#2563eb',
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 8,
    },
    subscribeButtonText: {
        color: '#fff',
        fontWeight: '600',
    },
    historyItem: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        padding: 16,
        borderRadius: 12,
        marginBottom: 8,
        borderWidth: 1,
        borderColor: '#f3f4f6',
    },
    historyIcon: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: '#eff6ff',
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 12,
    },
    historyInfo: {
        flex: 1,
    },
    historyAcademy: {
        fontSize: 16,
        fontWeight: '600',
        color: '#111827',
        marginBottom: 2,
    },
    historyDate: {
        fontSize: 14,
        color: '#6b7280',
    },
    emptyText: {
        textAlign: 'center',
        color: '#9ca3af',
        marginTop: 16,
    },
    logoutButton: {
        margin: 16,
        padding: 16,
        backgroundColor: '#fee2e2',
        borderRadius: 12,
        alignItems: 'center',
    },
    logoutText: {
        color: '#991b1b',
        fontWeight: '600',
        fontSize: 16,
    },
    statsGrid: {
        flexDirection: 'row',
        gap: 16,
        padding: 16,
    },
    statCard: {
        flex: 1,
        backgroundColor: '#fff',
        padding: 16,
        borderRadius: 16,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
        elevation: 2,
    },
    inviteBanner: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: '#2563eb',
        margin: 16,
        marginTop: 0,
        padding: 16,
        borderRadius: 16,
        shadowColor: '#2563eb',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 8,
        elevation: 4,
    },
    inviteContent: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
    },
    inviteTextContainer: {
        flex: 1,
    },
    inviteTitle: {
        color: '#fff',
        fontSize: 16,
        fontWeight: 'bold',
    },
    inviteSubtitle: {
        color: '#bfdbfe',
        fontSize: 12,
    },
});
