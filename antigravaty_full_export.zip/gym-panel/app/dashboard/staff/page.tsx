'use client';

export default function PartnerStaff() {
    return (
        <div className="p-8 max-w-4xl mx-auto">
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900">Gerenciar Equipe</h1>
                <p className="text-gray-600 mt-2">Adicione funcionários que podem validar check-ins</p>
            </div>

            {/* Coming Soon Card */}
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 border border-blue-100 rounded-2xl p-12 text-center">
                <div className="text-6xl mb-6">👥</div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Em Breve</h2>
                <p className="text-gray-600 max-w-md mx-auto mb-6">
                    Em breve você poderá adicionar membros da sua equipe (recepcionistas, instrutores)
                    para que eles possam validar check-ins dos alunos diretamente pelo painel.
                </p>
                <div className="bg-white rounded-lg p-6 max-w-sm mx-auto">
                    <h3 className="font-bold text-gray-900 mb-3">Funcionalidades Futuras:</h3>
                    <ul className="text-sm text-gray-600 space-y-2 text-left">
                        <li>✅ Adicionar funcionários por email</li>
                        <li>✅ Definir permissões (apenas check-in ou admin)</li>
                        <li>✅ Ver histórico de ações da equipe</li>
                        <li>✅ Remover acesso quando necessário</li>
                    </ul>
                </div>
            </div>

            {/* Temporary Workaround */}
            <div className="mt-8 bg-blue-50 border border-blue-100 rounded-xl p-6">
                <h3 className="font-bold text-blue-900 mb-2">💡 Enquanto isso...</h3>
                <p className="text-sm text-blue-800">
                    Se você precisa dar acesso a um funcionário <strong>agora</strong>,
                    entre em contato com o suporte e nós faremos a configuração manualmente.
                </p>
            </div>
        </div>
    );
}
