'use client';

import { useEffect, useState } from 'react';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Checkin } from '@/types';
import Link from 'next/link';

export default function DashboardPage() {
    const [checkins, setCheckins] = useState<Checkin[]>([]);
    const [loading, setLoading] = useState(true);
    const supabase = createClientComponentClient();

    useEffect(() => {
        const fetchCheckins = async () => {
            const { data: { user } } = await supabase.auth.getUser();
            if (!user) return;

            // Fetch checkins for the logged user's academy
            // Note: This assumes RLS allows reading checkins linked to owned academy
            // Or we fetch all checkins if we are just testing
            const { data } = await supabase
                .from('checkins')
                .select('*, users(full_name, email)')
                .order('created_at', { ascending: false })
                .limit(50);

            if (data) setCheckins(data as unknown as Checkin[]);
            setLoading(false);
        };

        fetchCheckins();

        // Realtime subscription
        const channel = supabase
            .channel('checkins_realtime')
            .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'checkins' }, (payload) => {
                setCheckins((prev) => [payload.new as Checkin, ...prev]);
            })
            .subscribe();

        return () => {
            supabase.removeChannel(channel);
        };
    }, []);

    return (
        <div className="p-8 max-w-7xl mx-auto">
            <div className="mb-8">
                <h1 className="text-2xl font-bold text-gray-900">Visão Geral</h1>
                <p className="text-gray-500">Acompanhe o movimento da sua academia em tempo real.</p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-3 mb-8">
                <div className="bg-white overflow-hidden shadow-sm rounded-xl border border-gray-200 p-6">
                    <dt className="text-sm font-medium text-gray-500 truncate uppercase tracking-wider">Check-ins Hoje</dt>
                    <dd className="mt-2 text-4xl font-bold text-gray-900">{checkins.length}</dd>
                    <dd className="mt-1 text-sm text-green-600 font-medium flex items-center gap-1">
                        <span className="bg-green-100 px-1.5 py-0.5 rounded text-xs">▲ 12%</span> vs ontem
                    </dd>
                </div>
                <div className="bg-white overflow-hidden shadow-sm rounded-xl border border-gray-200 p-6">
                    <dt className="text-sm font-medium text-gray-500 truncate uppercase tracking-wider">Alunos Ativos</dt>
                    <dd className="mt-2 text-4xl font-bold text-gray-900">142</dd>
                    <dd className="mt-1 text-sm text-gray-400 font-medium">Total de membros</dd>
                </div>
                <div className="bg-gradient-to-br from-blue-600 to-indigo-700 overflow-hidden shadow-lg rounded-xl p-6 text-white relative">
                    <div className="absolute top-0 right-0 -mt-4 -mr-4 h-24 w-24 rounded-full bg-white opacity-10 blur-xl"></div>
                    <dt className="text-sm font-medium text-blue-100 truncate uppercase tracking-wider">Faturamento (Est.)</dt>
                    <dd className="mt-2 text-4xl font-bold text-white">R$ {(checkins.length * 12).toFixed(2)}</dd>
                    <dd className="mt-1 text-sm text-blue-200 font-medium">Baseado nos check-ins de hoje</dd>
                </div>
            </div>

            <div className="flex flex-col lg:flex-row gap-8">
                {/* Live Feed */}
                <div className="flex-1">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                            <span className="relative flex h-3 w-3">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                            </span>
                            Feed Ao Vivo
                        </h2>
                    </div>

                    <div className="bg-white shadow-sm rounded-xl border border-gray-200 overflow-hidden">
                        <ul className="divide-y divide-gray-50">
                            {checkins.map((checkin) => (
                                <li key={checkin.id} className="hover:bg-gray-50/50 transition-colors">
                                    <div className="px-6 py-5">
                                        <div className="flex items-center justify-between">
                                            <div className="flex items-center">
                                                <div className="flex-shrink-0 h-12 w-12 rounded-full bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center border-2 border-white shadow-sm">
                                                    <span className="text-blue-600 font-bold text-lg">
                                                        {checkin.users?.full_name?.[0] || 'U'}
                                                    </span>
                                                </div>
                                                <div className="ml-4">
                                                    <p className="text-sm font-bold text-gray-900">
                                                        {checkin.users?.full_name || 'Usuário Desconhecido'}
                                                    </p>
                                                    <p className="text-xs text-gray-500 flex items-center gap-1">
                                                        {checkin.users?.email}
                                                    </p>
                                                </div>
                                            </div>
                                            <div className="flex flex-col items-end">
                                                <span className="px-3 py-1 inline-flex text-xs leading-5 font-bold rounded-full bg-green-50 text-green-700 border border-green-100">
                                                    CONFIRMADO
                                                </span>
                                                <p className="mt-1 text-xs text-gray-400 font-medium">
                                                    {format(new Date(checkin.created_at), "HH:mm", { locale: ptBR })}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            ))}
                            {checkins.length === 0 && !loading && (
                                <li className="px-6 py-12 text-center text-gray-400 bg-gray-50/30">
                                    <p className="text-lg font-medium">A academia está tranquila.</p>
                                    <p className="text-sm">Nenhum check-in registrado hoje.</p>
                                </li>
                            )}
                        </ul>
                    </div>
                </div>

                {/* Side Widgets */}
                <div className="w-full lg:w-80 space-y-6">
                    <div className="bg-blue-50 rounded-xl p-6 border border-blue-100">
                        <h3 className="text-blue-900 font-bold mb-2">Precisa de ajuda?</h3>
                        <p className="text-blue-700 text-sm mb-4">Fale com nosso suporte técnico dedicado para parceiros.</p>
                        <button className="text-sm font-bold text-blue-600 hover:text-blue-800">
                            Contatar Suporte →
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
